#!/bin/bash
#untaint the node so that pods will get scheduled:
kubectl create ns testing
kubectl create -n testing  deployment testing --image nginx
sleep 60
A=$(kubectl -n testing get po | grep testing | awk '{print $3}')
if
  [[ $A  == running ]]
  then
  echo 'node already untaint'

  else
kubectl taint nodes --all node-role.kubernetes.io/master-
echo " node has been untaint and all pod will be schedule on master"
fi

