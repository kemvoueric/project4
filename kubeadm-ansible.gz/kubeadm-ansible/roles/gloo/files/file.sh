export PATH=$HOME/.gloo/bin:$PATH
glooctl version
glooctl upgrade --release v1.6.0

